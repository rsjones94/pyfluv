from streamgeometry import CrossSection
