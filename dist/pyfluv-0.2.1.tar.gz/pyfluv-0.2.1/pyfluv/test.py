# junk code for quick tests
import matplotlib.pyplot as plt
import numpy as np

import streammath as sm
import streamgeometry as strgeo
import graindistributions as grain

from westpineyriver import crosses

crosses[0].qplot()